package zad3;

/**
 * Created by Krzysztof Kaczynski on 11:11 - 14.05.2021.
 */
public class Rose extends Flower {
    public Rose(int quantity) {
        this.quantity = quantity;
        this.name = "róża";
        this.colour = "czerwony";
    }
}
