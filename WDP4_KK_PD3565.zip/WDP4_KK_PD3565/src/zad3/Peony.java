package zad3;

/**
 * Created by Krzysztof Kaczynski on 11:09 - 14.05.2021.
 */
public class Peony extends Flower {
    public Peony(int quantity) {
        this.quantity = quantity;
        this.name = "piwonia";
        this.colour = "czerwony";
    }
}
