package zad3;

/**
 * Created by Krzysztof Kaczynski on 11:07 - 14.05.2021.
 */
public class Freesia extends Flower {
    public Freesia(int quantity) {
        this.quantity = quantity;
        this.name = "frezja";
        this.colour = "żółty";
    }
}
