package zad3;

/**
 * Created by Krzysztof Kaczynski on 11:08 - 14.05.2021.
 */
public class Lilac extends Flower {
    public Lilac(int quantity) {
        this.quantity = quantity;
        this.name = "bez";
        this.colour = "biały";
    }
}